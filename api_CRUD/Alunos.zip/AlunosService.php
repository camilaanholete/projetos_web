<?php
    // Arquivo de controle : tipo de servicos oferecidos pelo Api   
    include 'Alunos.php'; //incluir o arquivo Alunos.php
    class AlunosService 
    {
          //Um método "get" para consulta de dados: (protocolo: "get" - buscar os dados no BD)
          // quando "$id = null" significa que pode ter ou não este parâmetro 
          public function get( $id = null )
          {
              if ($id){// se existe $id  
                 //retornar resultado do método select($id) da class Alunos            
                 return Alunos::select($id) ;
              }else{
                 //retornar resultado do método selectAll() da class Alunos 
                 return Alunos::selectAll() ;
              }

          }
          // funcão para inclusão de dados
          public function post()
          {
              
          }
          // funcão para alteração de dados
          public function update()
          {
              
          }
          // funcão para exclusão de dados
          public function delete()
          {
              
          }
    }